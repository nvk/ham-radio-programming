The two main folders are separated into 32 bit or 64 bit Operating Systems.  If you are not sure which version of Operating System you have, then please read the instructions below.   

Instructions:
	1. Determine which Operating System you have. (XP,Vista, Window 7, 95,ME,98,or 2000)

	2. Determine which Bit version OS you are running on (32 bit or 64 bit)
		note:  If you are not sure, then see the 32_or_64 bit Instructions below.

	3. Plug in the cable to see if computer detect the cable.  When the computer detects the
		cable, then a New Hardware Found wizard will appear.  If the wizard does not appear, 
		then manually install the drivers through the Add Hardware in the Control Panel

	4. Tell the computer where the drivers are located to install drivers
		Ex. Saved the folder on desktop, so the location of the drivers are in the
 		     		    folder on the desktop.
 


Window 7:	* 32 and 64 bit drivers are the same drivers in the Win_7 folders

For 64bit:	* XP and Vista are the same drivers in the 64_bit_Driver folders
		* Mac OS has its own drivers in the 64_bit_Drivers/Mac_OS folder

For 32bit:	* XP,98,ME,2000,95 has the same drivers in the 32_bit_Drivers/Win_XP folder
		* Vista has it's own drivers in the 32_bit_Driver/Win_Vista folder
		* Mac OS has it own drivers in the 32_bit_Drivers/Mac_OS folder




How to determine if you have 32_or_64 bit Instructions
************************************************************************************************
for XP
    * Click Start, then click on Run or Start Search.
    * Type msinfo32.exe and then press Enter key.
    * Under system Information  review the value for the System Type item:  
      	For 32-bit editions of Windows XP, the value of the System Type item is x86-based PC. 
      	For 64-bit editions of Windows XP, the value of the System Type item is x64-based PC.


for Vista
    * Click Start ? Run or Start Search.
    * Type msinfo32.exe and then press Enter.
    * Under "ystem Information" find the value for the System Type item: 
      	For 32-bit editions of Windows vista, the value of the System Type item is x86-based PC. 
      	For 64-bit editions of Windows vista, the value of the System Type item is x64-based PC.

for Window 7
    * Click Start.
    * Right-click My Computer, and then click Properties.
          If you don't see "x64 Edition" listed, then you're running the 32-bit version of Windows.
          If "x64 Edition" is listed under System, you're running the 64-bit version of Windows.
************************************************************************************************